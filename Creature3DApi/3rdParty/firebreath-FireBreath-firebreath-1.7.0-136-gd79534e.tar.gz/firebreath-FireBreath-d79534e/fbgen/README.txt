(This file came from /gen_templates)

The files in /gen_templates should not normally need to be edited
directly.  They are populated for each plugin using values either
computed or taken directly from PluginConfig.cmake in your project
directory
