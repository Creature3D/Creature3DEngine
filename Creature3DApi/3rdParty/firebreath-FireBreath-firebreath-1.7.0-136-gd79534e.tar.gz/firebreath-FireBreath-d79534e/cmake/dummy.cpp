// This is a dummy file used to allow CMake to create a project empty of real source files,
// e.g. for an installer project or a "header-file only" project in Visual Studio.

