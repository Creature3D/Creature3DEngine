
/**********************************************************\

  Auto-generated resource.h

\**********************************************************/

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by firebreathWin.rc
//
#define IDS_PROJNAME                    100
#define IDR_FIREBREATHWIN               101
#define IDB_FBCONTROL                   102
#define IDR_FBCONTROL                   103
#define IDH_FBCONTROL                   104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif

#define FB_LIBID LIBID_${FBTYPELIB_NAME}

